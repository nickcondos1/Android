package com.ncondos.nick.ncondoslab5;

public interface GetTimeListener
{
    public void getTime(int hour, int minute, int second);
}
